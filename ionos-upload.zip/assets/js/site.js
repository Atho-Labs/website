import { siteContent } from "./site-data.js?v=20260910b";

const iconPaths = {
  shield: "M12 2.4 4 5.6v5.7c0 5.2 3.4 9.9 8 11.3 4.6-1.4 8-6.1 8-11.3V5.6l-8-3.2Zm0 3.3 4.7 1.9v3.8c0 3.3-1.9 6.4-4.7 7.6-2.8-1.2-4.7-4.3-4.7-7.6V7.6L12 5.7Z",
  hash: "M10 2 4.8 22h2.4L12.4 2H10Zm6.4 0L11.2 22h2.4L18.8 2h-2.4ZM2 8.2v2.2h20V8.2H2Zm-1 5.4v2.2h20v-2.2H1Z",
  grid: "M3 3h7v7H3V3Zm11 0h7v7h-7V3ZM3 14h7v7H3v-7Zm11 0h7v7h-7v-7Z",
  layers: "M12 3 2 8l10 5 10-5-10-5Zm-8.6 8.5L12 16l8.6-4.5L22 13l-10 5-10-5 1.4-1.5Zm0 4.6L12 20l8.6-3.9L22 17.6l-10 5-10-5 1.4-1.5Z",
  pickaxe: "M20.8 5.1c-2.4-2-6.1-2.3-8.8-.7l2.6 2.6-2.1 2.1-3-3-6.7 6.7 1.4 1.4 2.6-2.6 2.9 2.9-4.6 4.6 1.5 1.5 4.6-4.6 2.9 2.9-2.6 2.6 1.4 1.4 6.7-6.7-3-3 2.1-2.1 2.6 2.6c1.6-2.7 1.3-6.4-.7-8.8ZM10.3 12.2l-1.8-1.8 1.5-1.5 1.8 1.8-1.5 1.5Z",
  bolt: "M13 2 4 13h5l-1 9 9-11h-5l1-9Z",
  server: "M4 4h16a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2Zm0 9h16a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2v-3a2 2 0 0 1 2-2Zm3-6a1.2 1.2 0 1 0 0 2.4A1.2 1.2 0 0 0 7 7Zm0 9a1.2 1.2 0 1 0 0 2.4A1.2 1.2 0 0 0 7 16Z",
  globe: "M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20Zm6.9 9h-3.1a15.4 15.4 0 0 0-1.6-5A8.1 8.1 0 0 1 18.9 11ZM12 4.1c.9 1.1 2.1 3.2 2.6 6H9.4c.5-2.8 1.7-4.9 2.6-6ZM5.8 6A15.4 15.4 0 0 0 4.2 11H1.1A8.1 8.1 0 0 1 5.8 6Zm0 12A8.1 8.1 0 0 1 1.1 13h3.1c.2 1.8.8 3.5 1.6 5ZM12 19.9c-.9-1.1-2.1-3.2-2.6-6h5.2c-.5 2.8-1.7 4.9-2.6 6Zm2.8-1.9a15.4 15.4 0 0 0 1.6-5h3.1a8.1 8.1 0 0 1-4.7 5Z",
  wallet: "M4 6.5A2.5 2.5 0 0 1 6.5 4H19a2 2 0 0 1 2 2v2.2H6.5A1.5 1.5 0 0 0 5 9.7v7.8A2.5 2.5 0 0 1 2.5 15V8A2 2 0 0 1 4 6.5Zm2.5 3.2H21v7.8a2.5 2.5 0 0 1-2.5 2.5h-12A1.5 1.5 0 0 1 5 18.5v-7.3A1.5 1.5 0 0 1 6.5 9.7Zm10.3 4.1a1.4 1.4 0 1 0 0 2.8 1.4 1.4 0 0 0 0-2.8Z",
  monitor: "M4 4h16a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2h-6l1.2 2H18v2H6v-2h2.8l1.2-2H4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2Zm0 2v10h16V6H4Z",
  spark: "M12 2.5 14 8l5.5.3-4.3 3.4 1.5 5.3L12 13.7 7.3 17l1.5-5.3-4.3-3.4L10 8l2-5.5Z",
  code: "M8.6 7 3.2 12l5.4 5 1.5-1.6L6.5 12l3.6-3.4L8.6 7Zm6.8 0-1.5 1.6 3.6 3.4-3.6 3.4 1.5 1.6 5.4-5-5.4-5ZM9.8 20h2.4l2-16H11.8l-2 16Z",
  database: "M12 3C7 3 3 4.6 3 6.5v11C3 19.4 7 21 12 21s9-1.6 9-3.5v-11C21 4.6 17 3 12 3Zm0 2c4.4 0 7 .9 7 1.5S16.4 8 12 8 5 7.1 5 6.5 7.6 5 12 5Zm0 6c4.4 0 7-.9 7-1.5v2.6c0 .6-2.6 1.5-7 1.5s-7-.9-7-1.5V9.5c0 .6 2.6 1.5 7 1.5Zm0 6c4.4 0 7-.9 7-1.5v2c0 .6-2.6 1.5-7 1.5s-7-.9-7-1.5v-2c0 .6 2.6 1.5 7 1.5Z",
  terminal: "M3 5.5A2.5 2.5 0 0 1 5.5 3h13A2.5 2.5 0 0 1 21 5.5v13a2.5 2.5 0 0 1-2.5 2.5h-13A2.5 2.5 0 0 1 3 18.5v-13Zm3.2 2.3 3.1 3.1-3.1 3.1 1.4 1.4 4.5-4.5-4.5-4.5-1.4 1.4ZM12 15h5v-2h-5v2Z",
  package: "M12 2 3 6.5V17L12 22l9-5V6.5L12 2Zm0 2.3 6.4 3.2L12 10.7 5.6 7.5 12 4.3Zm-7 5.2 6 3v7.1l-6-3v-7.1Zm8 10.1v-7.1l6-3v7.1l-6 3Z"
};

const statusClassMap = {
  Live: "status-live",
  Current: "status-live",
  Implemented: "status-live",
  GitHub: "status-docs",
  Building: "status-building",
  Pending: "status-placeholder",
  Published: "status-live",
  Planned: "status-planned",
  Docs: "status-docs",
  Editable: "status-editable",
  Placeholder: "status-placeholder",
  Now: "status-now",
  "In Progress": "status-progress",
  Next: "status-next"
};

const brandIconPaths = {
  github: "M12 .297c-6.63 0-12 5.373-12 12 0 5.303 3.438 9.8 8.205 11.385.6.113.82-.258.82-.577 0-.285-.01-1.04-.015-2.04-3.338.724-4.042-1.61-4.042-1.61-.546-1.385-1.335-1.755-1.335-1.755-1.087-.744.084-.729.084-.729 1.205.084 1.838 1.236 1.838 1.236 1.07 1.835 2.809 1.305 3.495.998.108-.776.417-1.305.76-1.605-2.665-.3-5.466-1.332-5.466-5.93 0-1.31.465-2.38 1.235-3.22-.135-.303-.54-1.523.105-3.176 0 0 1.005-.322 3.3 1.23.96-.267 1.98-.399 3-.405 1.02.006 2.04.138 3 .405 2.28-1.552 3.285-1.23 3.285-1.23.645 1.653.24 2.873.12 3.176.765.84 1.23 1.91 1.23 3.22 0 4.61-2.805 5.625-5.475 5.92.42.36.81 1.096.81 2.22 0 1.606-.015 2.896-.015 3.286 0 .315.21.69.825.57C20.565 22.092 24 17.592 24 12.297c0-6.627-5.373-12-12-12",
  discord: "M20.317 4.3698a19.7913 19.7913 0 0 0-4.8851-1.5152.0741.0741 0 0 0-.0785.0371c-.211.3753-.4447.8648-.6083 1.2495-1.8447-.2762-3.68-.2762-5.4868 0-.1636-.3933-.4058-.8742-.6177-1.2495a.077.077 0 0 0-.0785-.037 19.7363 19.7363 0 0 0-4.8852 1.515.0699.0699 0 0 0-.0321.0277C.5334 9.0458-.319 13.5799.0992 18.0578a.0824.0824 0 0 0 .0312.0561c2.0528 1.5076 4.0413 2.4228 5.9929 3.0294a.0777.0777 0 0 0 .0842-.0276c.4616-.6304.8731-1.2952 1.226-1.9942a.076.076 0 0 0-.0416-.1057c-.6528-.2476-1.2743-.5495-1.8722-.8923a.077.077 0 0 1-.0076-.1277c.1258-.0943.2517-.1923.3718-.2914a.0743.0743 0 0 1 .0776-.0105c3.9278 1.7933 8.18 1.7933 12.0614 0a.0739.0739 0 0 1 .0785.0095c.1202.099.246.1981.3728.2924a.077.077 0 0 1-.0066.1276 12.2986 12.2986 0 0 1-1.873.8914.0766.0766 0 0 0-.0407.1067c.3604.698.7719 1.3628 1.225 1.9932a.076.076 0 0 0 .0842.0286c1.961-.6067 3.9495-1.5219 6.0023-3.0294a.077.077 0 0 0 .0313-.0552c.5004-5.177-.8382-9.6739-3.5485-13.6604a.061.061 0 0 0-.0312-.0286zM8.02 15.3312c-1.1825 0-2.1569-1.0857-2.1569-2.419 0-1.3332.9555-2.4189 2.157-2.4189 1.2108 0 2.1757 1.0952 2.1568 2.419 0 1.3332-.9555 2.4189-2.1569 2.4189zm7.9748 0c-1.1825 0-2.1569-1.0857-2.1569-2.419 0-1.3332.9554-2.4189 2.1569-2.4189 1.2108 0 2.1757 1.0952 2.1568 2.419 0 1.3332-.946 2.4189-2.1568 2.4189Z",
  x: "M18.244 2.25h3.308l-7.227 8.26 8.502 11.24h-6.657l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231 5.45-6.231Zm-1.161 17.52h1.833L7.084 4.126H5.117L17.083 19.77Z"
};

const siteBase = document.body?.dataset?.siteBase?.trim() || "./";

function resolveSiteHref(href) {
  if (!href) {
    return href;
  }
  if (/^(?:[a-z]+:|#|\/)/i.test(href)) {
    return href;
  }
  if (href.startsWith("./")) {
    return `${siteBase}${href.slice(2)}`;
  }
  return href;
}

function createIcon(name) {
  const wrap = document.createElement("span");
  wrap.className = name === "shield" || name === "hash" || name === "grid" || name === "layers" || name === "pickaxe" || name === "bolt"
    ? "feature-icon"
    : "ecosystem-icon";

  const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svg.setAttribute("viewBox", "0 0 24 24");
  svg.setAttribute("aria-hidden", "true");
  const path = document.createElementNS("http://www.w3.org/2000/svg", "path");
  path.setAttribute("d", iconPaths[name] || iconPaths.spark);
  svg.appendChild(path);
  wrap.appendChild(svg);
  return wrap;
}

function createBadge(label) {
  const badge = document.createElement("span");
  badge.className = `status-badge ${statusClassMap[label] || "status-planned"}`;
  badge.textContent = label;
  return badge;
}

function createCardSurface({ href = "", className = "" } = {}) {
  const resolvedHref = resolveSiteHref(href);
  if (resolvedHref) {
    const link = document.createElement("a");
    link.className = className;
    link.href = resolvedHref;
    return link;
  }

  const article = document.createElement("article");
  article.className = className;
  return article;
}

function appendHoverDetail(card, text) {
  if (!(card instanceof HTMLElement) || !text) {
    return;
  }

  card.classList.add("card-hoverable");
  if (!card.hasAttribute("tabindex")) {
    card.tabIndex = 0;
  }

  const detail = document.createElement("div");
  detail.className = "card-hover-detail";
  detail.innerHTML = `
    <span>More</span>
    <p>${text}</p>
  `;
  card.appendChild(detail);
}

function hydrateStaticHoverCards() {
  document.querySelectorAll("[data-hover-copy]").forEach((node) => {
    if (!(node instanceof HTMLElement)) {
      return;
    }

    appendHoverDetail(node, node.dataset.hoverCopy || "");
  });
}

function renderHeroSignals() {
  const target = document.querySelector("#hero-signals");
  if (!(target instanceof HTMLElement)) {
    return;
  }

  siteContent.heroSignals.forEach((label) => {
    const chip = document.createElement("span");
    chip.className = "signal-chip";
    chip.textContent = label;
    target.appendChild(chip);
  });
}

function renderProtocolHighlights() {
  const target = document.querySelector("#protocol-highlights");
  if (!(target instanceof HTMLElement)) {
    return;
  }

  siteContent.protocolHighlights.forEach((item) => {
    const article = document.createElement("article");
    article.className = "card number-card";
    article.setAttribute("data-reveal", "");
    article.innerHTML = `
      <span class="eyebrow-number">${item.number}</span>
      <div>
        <h3>${item.title}</h3>
        <p>${item.copy}</p>
      </div>
    `;
    appendHoverDetail(article, item.hover);
    target.appendChild(article);
  });
}

function renderRuntimePills() {
  const target = document.querySelector("#runtime-pills");
  if (!(target instanceof HTMLElement)) {
    return;
  }

  siteContent.runtimePills.forEach((item) => {
    const card = document.createElement("article");
    card.className = "pill-card";
    card.setAttribute("data-reveal", "");
    card.innerHTML = `
      <span class="pill-label">${item.label}</span>
      <strong>${item.value}</strong>
      <p>${item.copy}</p>
    `;
    appendHoverDetail(card, item.hover);
    target.appendChild(card);
  });
}

function renderNetworkConstants() {
  const target = document.querySelector("#network-constants");
  if (!(target instanceof HTMLElement)) {
    return;
  }

  siteContent.networkConstants.forEach((item) => {
    const card = createCardSurface({
      href: item.href,
      className: "network-constant-card simple-link-card"
    });
    card.setAttribute("data-reveal", "");
    card.innerHTML = `
      <span>${item.name}</span>
      <strong class="stack-value">${item.value}</strong>
      <p><code>${item.detail}</code></p>
      <p>${item.copy}</p>
      <em class="simple-link-meta">${item.actionLabel || "Open docs"}</em>
    `;
    appendHoverDetail(card, item.hover);
    target.appendChild(card);
  });
}

function renderStats() {
  const target = document.querySelector("#network-stats");
  if (!(target instanceof HTMLElement)) {
    return;
  }

  siteContent.stats.forEach((item) => {
    const card = document.createElement("article");
    card.className = "card stat-card";
    card.setAttribute("data-reveal", "");
    card.dataset.statKey = item.key;
    card.innerHTML = `
      <span class="stat-meta ${statusClassMap[item.badge] || ""}">${item.badge}</span>
      <strong class="stat-value">${item.value}</strong>
      <h3>${item.label}</h3>
      <p>${item.detail}</p>
    `;
    appendHoverDetail(card, item.hover);
    target.appendChild(card);
  });
}

function renderCoreFeatures() {
  const target = document.querySelector("#core-features");
  if (!(target instanceof HTMLElement)) {
    return;
  }

  siteContent.coreFeatures.forEach((item) => {
    const card = createCardSurface({
      href: item.href,
      className: "card feature-card simple-link-card"
    });
    card.setAttribute("data-reveal", "");
    card.appendChild(createIcon(item.icon));

    const content = document.createElement("div");
    content.innerHTML = `
      <h3>${item.title}</h3>
      <p>${item.copy}</p>
      <em class="simple-link-meta">${item.actionLabel || "Open docs"}</em>
    `;
    card.appendChild(content);
    appendHoverDetail(card, item.hover);
    target.appendChild(card);
  });
}

function renderHomepageAccess() {
  const target = document.querySelector("#access-links");
  if (!(target instanceof HTMLElement)) {
    return;
  }

  siteContent.homepageAccess.forEach((item) => {
    const card = createCardSurface({
      href: item.href,
      className: "ecosystem-card simple-link-card"
    });
    card.setAttribute("data-reveal", "");

    const top = document.createElement("div");
    top.className = "ecosystem-card-top";

    const left = document.createElement("div");
    left.style.display = "flex";
    left.style.gap = "14px";
    left.style.alignItems = "flex-start";
    left.appendChild(createIcon(item.icon));

    const text = document.createElement("div");
    text.innerHTML = `
      <h3>${item.title}</h3>
      <p>${item.copy}</p>
      <em class="simple-link-meta">${item.actionLabel}</em>
    `;
    left.appendChild(text);
    top.appendChild(left);

    card.appendChild(top);
    appendHoverDetail(card, item.hover);
    target.appendChild(card);
  });
}

function renderEcosystem() {
  const target = document.querySelector("#ecosystem-groups");
  if (!(target instanceof HTMLElement)) {
    return;
  }

  siteContent.ecosystemGroups.forEach((group) => {
    const wrapper = document.createElement("section");
    wrapper.className = "ecosystem-group";
    wrapper.setAttribute("data-reveal", "");

    const head = document.createElement("div");
    head.className = "ecosystem-group-head";
    head.innerHTML = `<h3>${group.title}</h3>`;
    wrapper.appendChild(head);

    const grid = document.createElement("div");
    grid.className = "ecosystem-grid";

    group.items.forEach((item) => {
      const card = document.createElement("article");
      card.className = "ecosystem-card";

      const top = document.createElement("div");
      top.className = "ecosystem-card-top";

      const left = document.createElement("div");
      left.style.display = "flex";
      left.style.gap = "14px";
      left.style.alignItems = "flex-start";
      left.appendChild(createIcon(item.icon));

      const text = document.createElement("div");
      text.innerHTML = `
        <h3>${item.title}</h3>
        <p>${item.copy}</p>
      `;
      left.appendChild(text);
      top.appendChild(left);
      top.appendChild(createBadge(item.status));

      const action = document.createElement("a");
      action.className = "ecosystem-action";
      action.href = resolveSiteHref(item.actionHref);
      action.textContent = item.actionLabel;
      if (item.external) {
        action.target = "_blank";
        action.rel = "noopener noreferrer";
      }

      card.appendChild(top);
      card.appendChild(action);
      appendHoverDetail(card, item.hover);
      grid.appendChild(card);
    });

    wrapper.appendChild(grid);
    target.appendChild(wrapper);
  });
}

function renderEconomics() {
  const target = document.querySelector("#economics-grid");
  if (!(target instanceof HTMLElement)) {
    return;
  }

  siteContent.economics.forEach((item) => {
    const card = document.createElement("article");
    card.className = "card economics-card";
    card.setAttribute("data-reveal", "");
    card.innerHTML = `
      <span class="economics-badge ${statusClassMap[item.badge] || ""}">${item.badge}</span>
      <h3>${item.label}</h3>
      <strong class="economics-value">${item.value}</strong>
      <p>${item.note}</p>
    `;
    appendHoverDetail(card, item.hover);
    target.appendChild(card);
  });
}

function renderDeveloperPoints() {
  const target = document.querySelector("#developer-points");
  if (!(target instanceof HTMLElement)) {
    return;
  }

  siteContent.developerPoints.forEach((item) => {
    const li = document.createElement("li");
    li.textContent = item;
    target.appendChild(li);
  });
}

function renderDeveloperCommands() {
  const target = document.querySelector("#developer-commands");
  if (!(target instanceof HTMLElement)) {
    return;
  }

  siteContent.developerCommands.forEach((item) => {
    if (item.kind === "comment") {
      const comment = document.createElement("div");
      comment.className = "terminal-comment";
      comment.textContent = item.text;
      target.appendChild(comment);
      return;
    }

    const line = document.createElement("div");
    line.className = "terminal-line";
    const prompt = document.createElement("span");
    prompt.className = "terminal-prompt";
    prompt.textContent = item.prompt;
    const command = document.createElement("span");
    command.className = "terminal-command";
    command.textContent = item.text;
    line.append(prompt, command);
    target.appendChild(line);
  });
}

function renderStatusCards() {
  const target = document.querySelector("#status-cards");
  if (!(target instanceof HTMLElement)) {
    return;
  }

  siteContent.statusCards.forEach((item) => {
    const card = document.createElement("article");
    card.className = "card status-card";
    card.setAttribute("data-reveal", "");
    card.appendChild(createBadge(item.label));
    const body = document.createElement("div");
    body.innerHTML = `
      <h3>${item.title}</h3>
      <p>${item.copy}</p>
    `;
    card.appendChild(body);
    appendHoverDetail(card, item.hover);
    target.appendChild(card);
  });
}

function renderCommunityActions() {
  const target = document.querySelector("#community-actions");
  if (!(target instanceof HTMLElement)) {
    return;
  }

  siteContent.communityActions.forEach((item) => {
    const link = document.createElement("a");
    link.className = `button button-${item.variant}`;
    link.href = resolveSiteHref(item.href);
    link.textContent = item.label;
    if (item.external) {
      link.target = "_blank";
      link.rel = "noopener noreferrer";
    }
    target.appendChild(link);
  });
}

function renderFooterColumns() {
  const target = document.querySelector("#footer-columns");
  if (!(target instanceof HTMLElement)) {
    return;
  }

  siteContent.footerColumns.forEach((column) => {
    const section = document.createElement("div");
    section.className = "footer-column";

    const title = document.createElement("span");
    title.className = "footer-column-title";
    title.textContent = column.title;
    section.appendChild(title);

    column.links.forEach((item) => {
      const link = document.createElement("a");
      link.href = resolveSiteHref(item.href);
      const label = document.createElement("span");
      label.textContent = item.label;
      link.appendChild(label);
      if (item.badge) {
        link.classList.add("has-badge");
        const badge = createBadge(item.badge);
        badge.classList.add("footer-link-badge");
        link.appendChild(badge);
      }
      if (item.external) {
        link.target = "_blank";
        link.rel = "noopener noreferrer";
      }
      section.appendChild(link);
    });

    target.appendChild(section);
  });
}

function createSocialLinks(position) {
  const group = document.createElement("div");
  group.className = `social-links social-links-${position}`;
  group.setAttribute("aria-label", "Atho community links");

  siteContent.socialLinks.forEach((item) => {
    const link = document.createElement("a");
    link.className = "social-icon-link";
    link.href = item.href;
    link.target = "_blank";
    link.rel = "noopener noreferrer";
    link.setAttribute("aria-label", item.label);
    link.title = item.label;

    const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    svg.setAttribute("viewBox", "0 0 24 24");
    svg.setAttribute("aria-hidden", "true");
    const path = document.createElementNS("http://www.w3.org/2000/svg", "path");
    path.setAttribute("d", brandIconPaths[item.icon]);
    svg.appendChild(path);
    link.appendChild(svg);
    group.appendChild(link);
  });

  return group;
}

function renderSocialLinks() {
  const headerTarget = document.querySelector(".nav-actions, .docs-header-actions");
  if (headerTarget instanceof HTMLElement && !headerTarget.querySelector(".social-links-header")) {
    headerTarget.prepend(createSocialLinks("header"));
  }

  const footerTarget = document.querySelector(".footer-brand");
  if (footerTarget instanceof HTMLElement && !footerTarget.querySelector(".social-links-footer")) {
    footerTarget.appendChild(createSocialLinks("footer"));
  }
}

function initReveal() {
  const items = document.querySelectorAll("[data-reveal]");
  if (!items.length) {
    return;
  }

  const params = new URLSearchParams(window.location.search);
  if (params.has("capture")) {
    items.forEach((item) => item.classList.add("is-visible"));
    return;
  }

  if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
    items.forEach((item) => item.classList.add("is-visible"));
    return;
  }

  const observer = new IntersectionObserver((entries, currentObserver) => {
    entries.forEach((entry) => {
      if (!entry.isIntersecting) {
        return;
      }

      entry.target.classList.add("is-visible");
      currentObserver.unobserve(entry.target);
    });
  }, {
    threshold: 0.16,
    rootMargin: "0px 0px -8% 0px"
  });

  const viewportHeight = window.innerHeight || document.documentElement.clientHeight;

  items.forEach((item) => {
    const rect = item.getBoundingClientRect();
    if (rect.top < viewportHeight * 0.92) {
      item.classList.add("is-visible");
      return;
    }

    observer.observe(item);
  });
}

function initMenu() {
  const toggle = document.querySelector("[data-menu-toggle]");
  const panel = document.querySelector("[data-nav-panel]");
  if (!(toggle instanceof HTMLButtonElement) || !(panel instanceof HTMLElement)) {
    return;
  }

  const closeMenu = () => {
    document.body.classList.remove("nav-open");
    toggle.setAttribute("aria-expanded", "false");
  };

  toggle.addEventListener("click", () => {
    const isOpen = document.body.classList.toggle("nav-open");
    toggle.setAttribute("aria-expanded", String(isOpen));
  });

  panel.querySelectorAll("a").forEach((link) => {
    link.addEventListener("click", closeMenu);
  });

  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape") {
      closeMenu();
    }
  });

  document.addEventListener("click", (event) => {
    if (!document.body.classList.contains("nav-open")) {
      return;
    }
    if (panel.contains(event.target) || toggle.contains(event.target)) {
      return;
    }
    closeMenu();
  });

  window.addEventListener("resize", () => {
    if (window.innerWidth >= 980) {
      closeMenu();
    }
  });
}

function initYear() {
  document.querySelectorAll("[data-year]").forEach((node) => {
    node.textContent = String(new Date().getFullYear());
  });
}

function initSupplyCounter() {
  const counter = document.querySelector("[data-supply-counter]");
  if (!(counter instanceof HTMLElement)) {
    return;
  }

  const target = Number.parseInt(counter.dataset.target || "", 10);
  if (!Number.isFinite(target) || target <= 0) {
    return;
  }

  const formatter = new Intl.NumberFormat("en-US");
  const render = (value) => {
    counter.textContent = formatter.format(Math.min(target, Math.max(0, Math.round(value))));
  };

  if (window.matchMedia("(prefers-reduced-motion: reduce)").matches || !("IntersectionObserver" in window)) {
    render(target);
    return;
  }

  render(0);
  const observer = new IntersectionObserver((entries, currentObserver) => {
    if (!entries.some((entry) => entry.isIntersecting)) {
      return;
    }

    currentObserver.disconnect();
    const startedAt = performance.now();
    const duration = 2800;
    const step = (now) => {
      const progress = Math.min(1, (now - startedAt) / duration);
      const eased = 1 - Math.pow(1 - progress, 4);
      render(target * eased);
      if (progress < 1) {
        window.requestAnimationFrame(step);
      }
    };
    window.requestAnimationFrame(step);
  }, { threshold: 0.45 });

  observer.observe(counter);
}

async function hydrateStats() {
  const endpoint = document.body.dataset.statsEndpoint?.trim();
  if (!endpoint) {
    return;
  }

  try {
    const response = await fetch(endpoint, { headers: { Accept: "application/json" } });
    if (!response.ok) {
      throw new Error(`Stats request failed with ${response.status}`);
    }

    const data = await response.json();
    siteContent.stats.forEach((item) => {
      if (!(item.key in data)) {
        return;
      }

      const card = document.querySelector(`[data-stat-key="${item.key}"]`);
      if (!(card instanceof HTMLElement)) {
        return;
      }

      const value = card.querySelector(".stat-value");
      const meta = card.querySelector(".stat-meta");
      const detail = card.querySelector("p");
      if (value) {
        value.textContent = String(data[item.key]);
      }
      if (meta) {
        meta.textContent = "Live";
        meta.className = "stat-meta status-live";
      }
      if (detail) {
        detail.textContent = "Live network feed.";
      }
    });
  } catch {
    /* keep placeholders when no public stats feed is connected */
  }
}

let networkStatusRefreshPending = false;

async function hydrateNetworkStatus() {
  const statusEndpoint = document.body.dataset.networkStatusEndpoint?.trim();
  const statsEndpoint = document.body.dataset.networkStatsEndpoint?.trim();
  const band = document.querySelector("[data-network-status-band]");
  const title = document.querySelector("[data-network-status-title]");
  const note = document.querySelector("[data-network-status-note]");
  const heightValue = document.querySelector("[data-network-height]");
  const supplyValue = document.querySelector("[data-network-supply]");
  const halvingValue = document.querySelector("[data-network-halving]");
  const halvingReward = document.querySelector("[data-network-halving-reward]");
  const requiredElements = [band, title, note, heightValue, supplyValue, halvingValue, halvingReward];
  if (!statusEndpoint || !statsEndpoint || requiredElements.some((element) => !(element instanceof HTMLElement))) {
    return;
  }
  if (networkStatusRefreshPending) {
    return;
  }
  networkStatusRefreshPending = true;

  const formatDecimal = (rawValue) => {
    const match = String(rawValue ?? "").trim().match(/^(-?)(\d+)(?:\.(\d+))?/);
    if (!match) {
      return "--";
    }
    const whole = match[2].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    const fraction = String(match[3] || "").replace(/0+$/, "");
    return `${match[1]}${whole}${fraction ? `.${fraction}` : ""}`;
  };

  try {
    const [statusResponse, statsResponse] = await Promise.all([
      fetch(statusEndpoint, { headers: { Accept: "application/json" } }),
      fetch(statsEndpoint, { headers: { Accept: "application/json" } })
    ]);
    const [statusPayload, statsPayload] = await Promise.all([
      statusResponse.json(),
      statsResponse.json()
    ]);
    const status = statusPayload?.data;
    const stats = statsPayload?.data;
    const expectedGenesis = "0000347169b75a28f067fbc208a143e98e594709c4a3632ce44d48c7916dbabd50662e5e2e9073e5043d0455d6010af6";
    if (
      !statusResponse.ok
      || !statsResponse.ok
      || !statusPayload?.success
      || !statsPayload?.success
      || statusPayload.network_id !== "atho-testnet"
      || statsPayload.network_id !== "atho-testnet"
      || statusPayload.genesis_hash !== expectedGenesis
      || statsPayload.genesis_hash !== expectedGenesis
      || !status?.running
      || !status?.api_online
      || !status?.index?.ready
    ) {
      throw new Error("testnet status response is not ready");
    }

    const height = new Intl.NumberFormat("en-US").format(Number(stats.height || 0));
    const blocksUntilHalving = new Intl.NumberFormat("en-US").format(Number(stats.blocks_until_next_era || 0));
    const currentReward = formatDecimal(stats.current_reward_atho);
    const nextReward = formatDecimal(stats.next_era_reward_atho);
    title.textContent = "Public V1 testnet";
    note.textContent = status.safe_to_serve ? "Online and fully indexed" : "Synchronizing verified chain data";
    heightValue.textContent = height;
    supplyValue.textContent = `${formatDecimal(stats.circulating_supply)} ATHO`;
    halvingValue.textContent = `${blocksUntilHalving} blocks`;
    halvingReward.textContent = `${currentReward} to ${nextReward} ATHO`;
    band.classList.add("is-live");
    band.classList.remove("is-degraded");
  } catch {
    title.textContent = "Public V1 testnet";
    note.textContent = "Live status temporarily unavailable";
    heightValue.textContent = "--";
    supplyValue.textContent = "--";
    halvingValue.textContent = "--";
    halvingReward.textContent = "Reward schedule";
    band.classList.remove("is-live");
    band.classList.add("is-degraded");
  } finally {
    networkStatusRefreshPending = false;
  }
}

function renderPage() {
  renderHeroSignals();
  renderProtocolHighlights();
  renderRuntimePills();
  renderNetworkConstants();
  renderStats();
  renderCoreFeatures();
  renderHomepageAccess();
  renderEcosystem();
  renderEconomics();
  renderDeveloperPoints();
  renderDeveloperCommands();
  renderStatusCards();
  renderCommunityActions();
  renderFooterColumns();
  renderSocialLinks();
  hydrateStaticHoverCards();
  initMenu();
  initReveal();
  initYear();
  initSupplyCounter();
  hydrateStats();
  hydrateNetworkStatus();
  if (document.body.dataset.networkStatusEndpoint) {
    window.setInterval(hydrateNetworkStatus, 15_000);
  }
}

renderPage();
